def temp(t,ch):
	if ch == "c" or ch == "c":
		return t + "C"
	else:
		return t + "F"

t=input("Enter Temperature : ")
ch=input("Enter the Unit (T/F) ")
ret = temp(t,ch)
print("The Temperature is " +  ret)