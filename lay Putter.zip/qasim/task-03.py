def factor(n):
	factor_list = []
	for i in range(1 , n+1):
		if n % i == 0 :
			factor_list.append(i)

	return factor_list
# number = int(input("Enter a Number : "))
# ret = factor(number)
# print(ret)

def display(start , end):
	number = int(input("Enter a Number : "))
	ret = factor(number)
	print(ret)
	for i in range(len(ret)):
		if ret[i] > start and ret[i] < end:
			print(ret[i])

	
start = int(input("Enter the upper limit : "))
end = int(input ("Enter the lower limit : "))
display(start , end)


