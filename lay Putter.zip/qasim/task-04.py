def calculate_grade(marks):
	if marks < 50 :
		return "F"
	elif marks <=60:
		return "D"
	elif marks <=70:
		return "C"
	elif marks <=80:
		return "B"
	elif marks <=90:
		return "A"
	elif marks <=100:
		return "+A"
	else:
		print("Please check your inputs :")


while(True):
	marks = int(input("Enter the marks bro! :"))
	print(calculate_grade(marks))

